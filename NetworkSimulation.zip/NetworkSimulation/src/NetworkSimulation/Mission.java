package NetworkSimulation;

import java.util.*;

public class Mission {
	protected int priority;
	protected ArrayList<Workflow> workflows;
	protected int id;
	
	private static int next_id = 0;

	public Mission(ArrayList<Workflow> workflows){
		this.workflows = workflows;
		this.priority = (int) (Math.random() * 10);
		this.id = next_id;
		for(Workflow w: workflows){
			w.priority = Math.max(w.priority, priority);
//			for(Connection c: w.connections){
//				c.priority = Math.max(w.priority, priority);
//			}
		}
		next_id++;
	}

	public void add(Workflow w){
		w.priority = Math.max(priority, w.priority);
		workflows.add(w);
	}

	public static ArrayList<Mission> generateMissions(ArrayList<Workflow> workflows, int number){
		ArrayList<Mission> missions = new ArrayList<Mission>();
		for(int i = 0; i < number; i++){
			Collections.shuffle(workflows);
			int n = 1 + (int) (Math.random() * 3);
			ArrayList<Workflow> workflowsToAdd = new ArrayList<Workflow>(workflows.subList(0, n));
			missions.add(new Mission(workflowsToAdd));
		}
		return missions;
	}

	public String toString(){
		return "M" + id + "{workflows: " + workflows + ", priority: " + priority + "}";
	}

	public void updatePriority(int p){
		priority = p;
		for(Workflow w: workflows){
			w.priority = Math.max(w.priority, p);
		}
	}
}