package NetworkSimulation;

import java.util.*;
import javax.swing.*;
import java.awt.*;

import org.apache.commons.math3.distribution.*;

/**
 * Network Simulation
 * <p>
 * A tool for simulating various theories of resource allocation during emergency managment situations, made in conjunction with Saptarshi Debroy and Xioajie
 *
 * @author Jared Asch jaredasch1@gmail.com
 */
public class Simulation {
    public static final int NUM_CHANNELS = 5;
    public static final int NUM_WORKFLOWS = 10;
    public static final int NUM_DEVICES = 50;
    public static final int X_SIZE = 100;
    public static final int Y_SIZE = 100;
    public static final double LSDN_RAD = 80;
    public static final double CSDN_RAD = 100;
    public static final int SCALE = 5;

    public static final double BANDWITH_MEAN = 5E11;
    public static final double BANDWITH_SD = 2E11;

    public static final int CONNECTION_DURATION_MAX = 4;
    public static final int CONNECTION_DURATION_MIN = 1;

    public static final double IOT_MAX_RADIUS = 50;
    public static final double IOT_MIN_RADIUS = 36;     // 25 * sqrt(2), greatest distance possible between LSDN and IoT

//    public static final double CONNECTION_TIME_SD = 5;
//    public static final double CONNECTION_TIME_MEAN = 10;

    public static int DURATION = 10000;
    public static int INCREMENT = 1;

    public static JFrame window;
    public static JPanel container;
    public static JPanel panel;

    public static ArrayList<Channel> channels = new ArrayList<Channel>();
    public static ArrayList<Mission> missions = new ArrayList<Mission>();
    public static PriorityQueue<Workflow> workflows = new PriorityQueue<Workflow>(NUM_WORKFLOWS, new Comparator<Workflow>() {
        public int compare(Workflow w1, Workflow w2) {
            if (w1.priority > w2.priority) {
                return -1;
            } else if (w2.priority > w1.priority) {
                return 1;
            }
            return 0;
        }
    });
    public static ArrayList<Workflow> workflowsExecuting = new ArrayList<Workflow>();

    public static ArrayList<IoTDevice> iot_devices = new ArrayList<IoTDevice>();
    public static ArrayList<LocalSDN> LSDNs = new ArrayList<LocalSDN>();
    public static ArrayList<CentralSDN> CSDNs = new ArrayList<CentralSDN>();

    public static void main(String[] args) throws InterruptedException {
        setupGUI();

        channels = Channel.generateChannels();
        LSDNs = LocalSDN.genCornerLSDNs(X_SIZE, Y_SIZE, LSDN_RAD);
        iot_devices = IoTDevice.generateDevices();
        CSDNs.add(new CentralSDN(X_SIZE / 2, Y_SIZE / 2, CSDN_RAD));

        ArrayList<Workflow> workflowsTemp = Workflow.generateWorkflows(NUM_WORKFLOWS);
        for (Workflow w : workflowsTemp) workflows.add(w);
        allocateChannels();

        render();
//
        int nextWorkflowIntroduction = 0;
        for (int t = 0; t < DURATION; t++) {
            if (t == nextWorkflowIntroduction) {
                nextWorkflowIntroduction = t + new PoissonDistribution(5).sample();
                Workflow w = Workflow.generateWorkflow();
                workflows.add(w);
            }

            Fluctuation f = new Fluctuation();
            f.execute();

            allocateChannels();
            updateWorkflows();
            render();

            for(IoTDevice d: iot_devices)   if(Math.random() > 0.9) d.move();

            Scanner s = new Scanner(System.in);
            if (t % INCREMENT == 0) {
                System.out.println("ITERATION " + t);
                displayChannels();
                displayWorkflows();
                Thread.sleep(10);
//                Thread.sleep(1000);
//                System.out.print("Press any key to continue: ");
//                while (!s.hasNext()) ;
            }

        }
    }

    /**
     * Allocates a connection to one of the channels of the Simulation
     *
     * @param connection the connection that is to be allocated to a specific channel
     * @return a boolean representing whether or not the channel could be allocated
     */

    public static boolean allocateChannel(Connection connection) {
        connection.removeChannel();

        ArrayList<Channel> availableChannels = Simulation.channels;
//        if(connection.startpoint instanceof LocalSDN)   availableChannels = ((LocalSDN) connection.startpoint).channels;

        for (Channel c : availableChannels) {
            if (c.connections.size() == 0) {
                c.add(connection);
                connection.setChannel(c);
                return true;
            }
        }
        for (Channel c : availableChannels) {
            if (!connection.isInterferedBy(c.connections)) {
                c.add(connection);
                connection.setChannel(c);
                return true;
            }
        }
        for (Channel c : availableChannels) {
            Collections.sort(c.connections, Collections.reverseOrder());
            Iterator<Connection> iter = c.connections.iterator();
            Connection currentConnection = iter.next();
            while (iter.hasNext() && connection.priority() > currentConnection.priority()) {
                if (connection.isInterferedBy(currentConnection)) {
                    iter.remove();
                    currentConnection.removeChannel();
                    if (!connection.isInterferedBy(c.connections)) {
                        c.add(connection);
                        connection.setChannel(c);
                        return true;
                    }
                }
                currentConnection = iter.next();
            }
        }
        connection.removeChannel();
        return false;
    }

    /**
     * Allocates the the connections in each workflow to channels
     */

    public static void allocateChannels() {
        for(Channel c: channels){
            c.connections.clear();
        }
        for (Workflow w : workflows) {
            for (Connection c : w.connections) {
                allocateChannel(c);
            }
        }
    }

    public static synchronized void updateWorkflows() {
        Iterator<Workflow> iter = workflows.iterator();
        while(iter.hasNext()){
            Workflow current = iter.next();
            if(!current.stillValid()){
                current.regenPath();
            }
        }

        Iterator<Workflow> iterE = workflows.iterator();
        while (iterE.hasNext()) {
            Workflow current = iterE.next();
            if (current.isExecutable()) {
                workflowsExecuting.add(current);
                iterE.remove();
            }
        }

        Iterator<Workflow> iterEx = workflowsExecuting.iterator();
        while (iterEx.hasNext()) {
            Workflow current = iterEx.next();
            if (!current.isExecutable()) {
                iterEx.remove();
            } else if (--current.durationRemaining <= 0) {
                iterEx.remove();
                current.priority = -1;
                for (Channel chan : channels) {
                    chan.connections.removeAll(current.connections);
                }
            }
        }
    }

    public static void updateChannels() {
        for (Channel c : channels) {
            Iterator<Connection> iter = c.connections.iterator();
            Connection currentConnection;
            while (iter.hasNext()) {
                currentConnection = iter.next();
                if (--currentConnection.workflow.durationRemaining <= 0) {
                    iter.remove();
                    currentConnection.workflow.connections.poll();
                    if (currentConnection.workflow.connections.size() != 0) {
                        workflows.add(currentConnection.workflow);
                    }
                }
            }
        }
    }

    public static void displayWorkflows() {
        System.out.println("Workflows Executing:");
        for (Workflow w : workflowsExecuting) {
//            String res = w.debugString();
            String res = w.debugString() + " executing on channels ";
            for (Connection c : w.connections) {
                res += c.getChannel().id + " ";
            }

            System.out.println(res + System.lineSeparator());
        }
    }

    public static void displayMissions() {
        for (Mission m : missions) {
            System.out.println(m + System.lineSeparator());
        }
    }

    public static void displayChannels() {
        for (Channel c : channels) {
            System.out.println(c + System.lineSeparator());
        }
    }

    public static void setupGUI() {
        window = new JFrame("Network Simulation");
        window.setSize(X_SIZE * (SCALE + 1), Y_SIZE * (SCALE + 1));
        window.setLocationRelativeTo(null);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);

        panel = new JPanel(new SpringLayout());
        panel.setMinimumSize(new Dimension(SCALE * X_SIZE, SCALE * Y_SIZE));
        panel.setPreferredSize(new Dimension(SCALE * X_SIZE, SCALE * Y_SIZE));
        panel.setBackground(Color.WHITE);

        container = new JPanel(new GridBagLayout());
        container.setMinimumSize(new Dimension(X_SIZE * (SCALE + 1), Y_SIZE * (SCALE + 1)));
    }

    public static void render() {
        panel = new JPanel(new SpringLayout());
        panel.setMinimumSize(new Dimension(SCALE * X_SIZE, SCALE * Y_SIZE));
        panel.setPreferredSize(new Dimension(SCALE * X_SIZE, SCALE * Y_SIZE));
        panel.setBackground(Color.WHITE);

        container = new JPanel(new GridBagLayout());
        container.setMinimumSize(new Dimension(X_SIZE * (SCALE + 1), Y_SIZE * (SCALE + 1)));
        renderDevices();
        renderConnections();
    }

    public static void renderDevices() {
        for (Device d : iot_devices)
            panel.add(d);
        for (Device d : LSDNs)
            panel.add(d);
        for (Device d : CSDNs)
            panel.add(d);
        container.add(panel);
        window.getContentPane().add(container, BorderLayout.CENTER);
        window.setVisible(true);
    }

    public static void renderConnections() {
        for (Workflow w : workflowsExecuting) {
            for (Connection c : w.connections) {
                panel.add(c);
                panel.setComponentZOrder(c, 1);
            }
        }
        container.add(panel);
        window.getContentPane().add(container, BorderLayout.CENTER);
        window.setVisible(true);
    }
}