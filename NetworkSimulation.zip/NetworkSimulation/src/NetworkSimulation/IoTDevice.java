package NetworkSimulation;

import java.util.ArrayList;
import java.util.Arrays;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Color;

public class IoTDevice extends Device{
	private static final int HEIGHT = 1;
	private static final int WIDTH = 1;
	protected LocalSDN closestLSDN;

	public IoTDevice(double xcor, double ycor, double radius){
		super(xcor, ycor, radius);
		setClosestLSDN(Simulation.LSDNs);
	}

	public IoTDevice(double xcor, double ycor){
		this(xcor, ycor, Simulation.IOT_MIN_RADIUS + Math.random() * (Simulation.IOT_MAX_RADIUS - Simulation.IOT_MIN_RADIUS));
	}

	public static ArrayList<IoTDevice> generateDevices(){
		ArrayList<IoTDevice> result = new ArrayList<IoTDevice>();
		for(int i = 0; i < Simulation.NUM_DEVICES; i++){
			result.add(new IoTDevice(Math.random() * Simulation.X_SIZE, Math.random() * Simulation.Y_SIZE));
		}
		return result;
	}

	public void paintComponent(Graphics g){
		setLocation((int) xcor * Simulation.SCALE - (WIDTH * Simulation.SCALE / 2), (int) ycor * Simulation.SCALE - (HEIGHT * Simulation.SCALE / 2));
		setSize(WIDTH * Simulation.SCALE , HEIGHT * Simulation.SCALE);
		setBackground(Color.BLUE);
		super.paintComponent(g);
	}

	public boolean setClosestLSDN(ArrayList<LocalSDN> LSDNs){
		closestLSDN = closestLSDN(LSDNs);
		return true;
	}

	public void move(){
		this.xcor += (Math.random() - 0.5) * 5.0;
		this.ycor += (Math.random() - 0.5) * 5.0;
	}

	public String toString(){
		return "D" + id + "(" + (int) xcor + ", " + (int) ycor + ")";
	}


}