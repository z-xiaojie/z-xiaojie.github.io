package NetworkSimulation;

import java.util.*;

public class Fluctuation {
    public final static double PERCENT_MC = 0.1;
    public final static double PERCENT_MW = 0.1;
    public final static double PERCENT_UP = 0.1;

    public double modifyChannels;
    public double modifyWorkflows;
    public double updatePriorities;

    public Fluctuation() {
        modifyWorkflows = Math.random();
        modifyChannels = Math.random();
        updatePriorities = Math.random();
    }

    public void execute() {
        if (modifyChannels < PERCENT_MC) modifyChannels();
        if (modifyWorkflows < PERCENT_MW) modifyWorkflows();
        if (updatePriorities < PERCENT_UP) updatePriorities();
    }

    public void modifyChannels() {
        if (Math.random() < 0.5 && Simulation.channels.size() > 2) {
            Channel toRemove = Simulation.channels.get(Simulation.channels.size() - 1);
            for (Connection c : toRemove.connections) c.removeChannel();
            for (LocalSDN lsdn : Simulation.LSDNs) {
                if (lsdn.channels.contains(toRemove)) {
                    lsdn.channels.remove(toRemove);
                }
            }
            Simulation.channels.remove(Simulation.channels.size() - 1);
            Channel.next_id--;
        } else {
            Channel newChannel = new Channel();
            Simulation.channels.add(newChannel);
            for (LocalSDN lsdn : Simulation.LSDNs) {
                if (Math.random() > 0.5) lsdn.channels.add(newChannel);
            }
        }
    }

    public void modifyWorkflows() {
        if (Math.random() < 0.5) {
            Workflow w = Workflow.generateWorkflow();
            if (w.devices != null) Simulation.workflows.add(w);
        } else {
            if (Simulation.workflows.size() != 0) {
                Iterator<Workflow> iter = Simulation.workflows.iterator();
                int indexToRemove = (int) (Math.random() * Simulation.workflows.size());
                int ctr = 0;
                iter.next();
                while (iter.hasNext() && ctr++ != indexToRemove) iter.next();
                iter.remove();
            }
        }
    }

    public void updatePriorities() {
        // System.out.println("PRIORITIES MODFIED");
        for (Workflow w : Simulation.workflows) {
            if (Math.random() < 0.2) {
                w.priority = (int) (Math.random() * 10);
            }
        }
    }
}