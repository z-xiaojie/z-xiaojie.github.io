package NetworkSimulation;

import java.util.*;
import javax.swing.*;
import java.awt.*;

public class Connection extends JComponent implements Comparable<Connection> {
    protected Device startpoint;
    protected Device endpoint;
    protected int priority;
    protected Workflow workflow;
    protected int durationRemaining;
    private Channel channel = null;
    public int id;
    private static int next_id = 0;

    public Connection(Device startpoint, Device endpoint) {
        this.startpoint = startpoint;
        this.endpoint = endpoint;
        this.durationRemaining = generateConnectionTime();
        setPreferredSize(new Dimension(Simulation.SCALE * Simulation.X_SIZE, Simulation.SCALE * Simulation.Y_SIZE));
        id = next_id++;
    }

    public Device endpoint() {
        return endpoint;
    }

    public Device startpoint() {
        return startpoint;
    }

    public double priority() {
        return workflow.priority;
    }

    public void removeChannel() {
//        System.out.println("CHANNEL SET TO NULL");
        channel = null;
    }

    public void setChannel(Channel c) {
        channel = c;
    }

    public Channel getChannel() {
        return channel;
    }

    private double distance(Device a, Device b) {
        return Math.sqrt(Math.pow((a.xcor - b.xcor), 2) + Math.pow((a.ycor - b.ycor), 2));
    }

    public void paintComponent(Graphics g) {
        if (channel != null) {
            super.paintComponent(g);
            g.setColor(workflow.color);
            g.drawLine((int) startpoint.xcor * Simulation.SCALE, (int) startpoint.ycor * Simulation.SCALE, (int) endpoint.xcor * Simulation.SCALE, (int) endpoint.ycor * Simulation.SCALE);
            g.setColor(channel.color);
            g.drawString(Integer.toString(channel.id), (int) ((startpoint.xcor + endpoint.xcor) * Simulation.SCALE / 2), (int) ((startpoint.ycor + endpoint.ycor) * Simulation.SCALE / 2));
        }
    }

    public int compareTo(Connection other) {
        if (this.workflow.priority > other.workflow.priority) return 1;
        else if (other.workflow.priority > this.workflow.priority) return -1;
        return 0;
    }

    public boolean isInterferedBy(Connection c) {    // Checks if this is interfered by a different connection
        return distance(endpoint, c.startpoint) < c.startpoint.radius && endpoint != c.startpoint;
    }

    public boolean isInterferedBy(ArrayList<Connection> connections) {
        for (Connection c : connections) {
            if (isInterferedBy(c)) {
                return true;
            }
        }
        return false;
    }

    public boolean allocated(ArrayList<Channel> channels) {
        for (Channel c : channels) {
            if (c.connections.size() == 0) {
                c.add(this);
                return true;
            }
        }
        for (Channel c : channels) {
            if (!isInterferedBy(c.connections)) {
                c.add(this);
                return true;
            }
        }
        for (Channel c : channels) {
            for (Connection connection : c.connections) {
                if (this.workflow.priority > connection.workflow.priority && isInterferedBy(connection)) {
                    c.connections.remove(connection);
                }
                c.add(this);
                return true;
            }
        }
        return false;
    }

    private static int generateConnectionTime() {
        return (int) (Math.random() * (Simulation.CONNECTION_DURATION_MAX - Simulation.CONNECTION_DURATION_MIN)) + Simulation.CONNECTION_DURATION_MIN;
    }

    public String toString() {
        return "C(R" + durationRemaining + " " + workflow + ")";
    }

    public String debugString() {
        return "{Start Node: " + startpoint + ", End Node: " + endpoint + "difDist" + (startpoint.radius - startpoint.distance(endpoint)) + "}";
    }

    public static void main(String[] args) {
        Connection c1 = new Connection(new Device(50, 50, 200), new Device(60, 60, 10));
        Connection c2 = new Connection(new Device(100, 0, 20), new Device(100, 10, 20));

        System.out.println(c1.isInterferedBy(c2));    // Expected false
        System.out.println(c2.isInterferedBy(c1));    // Expected true
    }
}