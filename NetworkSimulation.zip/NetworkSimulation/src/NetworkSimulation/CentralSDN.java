package NetworkSimulation;

import java.util.ArrayList;
import java.util.Arrays;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Color;

public class CentralSDN extends Device{
	private static final int HEIGHT = 4;
	private static final int WIDTH = 4; 

	public CentralSDN(double xcor, double ycor, double radius){
		super(xcor, ycor, radius);
	}

	public void paintComponent(Graphics g){
		setLocation((int) xcor * Simulation.SCALE - (WIDTH * Simulation.SCALE / 2), (int) ycor * Simulation.SCALE - (HEIGHT * Simulation.SCALE / 2));
		setSize(WIDTH * Simulation.SCALE , HEIGHT * Simulation.SCALE);
		setBackground(Color.GREEN);
		super.paintComponent(g);
	} 

	public String toString(){
		return "CSDN" + id + "(" + xcor + ", " + ycor + ")";
	}
}