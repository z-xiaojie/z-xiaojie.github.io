package NetworkSimulation;

import java.util.*;
import java.awt.Color;

import org.apache.commons.math3.distribution.*;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultEdge;

public class Workflow implements Comparable<Workflow> {
    protected Queue<Connection> connections = new LinkedList<>();
    protected ArrayList<Device> devices = new ArrayList<>();
    protected double dataLeft;
    protected double priority = -1;
    protected int durationRemaining;
    protected int id;
    protected Color color;

    protected Device source;
    protected Device destination;

    private static int next_id = 0;

    public Queue<Connection> connections() {
        return connections;
    }

    public ArrayList<Device> devices() {
        return devices;
    }

    /**
     * Workflow contructor
     *
     * @param devices The devices to be a part of the workflow
     */

    public Workflow(Device src, Device dst) {
        source = src;
        destination = dst;
        devices = getPath();

        if (devices != null) {
            ArrayList<Device> devicesTemp = new ArrayList<Device>(devices);
            for (int i = 0; i < devices.size() - 1; i++)
                connections.add(new Connection(devicesTemp.get(i), devicesTemp.get(i + 1)));

            for (Connection c : connections)
                c.workflow = this;

            this.priority = Math.random() * 10;
            this.durationRemaining = (int) new ExponentialDistribution(20).sample();
            this.id = next_id;
            next_id++;

            Random random = new Random();
            color = Color.getHSBColor(random.nextFloat(), random.nextFloat(), random.nextFloat());
            System.out.println(this.debugString());
        }
    }

    public ArrayList<Device> getPath() {
        ArrayList<Device> devices = new ArrayList<Device>(Simulation.LSDNs);
        devices.add(source);
        devices.add(destination);

        DefaultDirectedGraph<Device, DefaultEdge> g = new DefaultDirectedGraph<Device, DefaultEdge>(DefaultEdge.class);
        for (Device d : devices) g.addVertex(d);
        for (int i = 0; i < devices.size(); i++)
            for (int k = 0; k < devices.size(); k++) {
                boolean isClosestLSDN = (devices.get(i) instanceof IoTDevice) ? devices.get(i).closestLSDN() == devices.get(k) : true;
                boolean isOwnDevice = (devices.get(i) instanceof LocalSDN && devices.get(k) instanceof IoTDevice) ? devices.get(k).closestLSDN() == devices.get(i) : true;
                boolean isAdjacentLSDN = (devices.get(i) instanceof LocalSDN && devices.get(k) instanceof LocalSDN) ? ((LocalSDN) devices.get(i)).isAdjacent((LocalSDN) devices.get(k)) : true;
                boolean iotsInSameCell = (devices.get(i) instanceof IoTDevice && devices.get(k) instanceof IoTDevice) ? ((IoTDevice) devices.get(i)).closestLSDN == ((IoTDevice) devices.get(k)).closestLSDN : true;
                if (devices.get(i).canTransmitTo(devices.get(k)) && isClosestLSDN && isOwnDevice && isAdjacentLSDN && iotsInSameCell) {
                    g.addEdge(devices.get(i), devices.get(k));
                }
            }
        DijkstraShortestPath<Device, DefaultEdge> d = new DijkstraShortestPath<Device, DefaultEdge>(g);
        GraphPath<Device, DefaultEdge> path = d.getPath(source, destination);
        if (path == null) return null;
        return new ArrayList<Device>(path.getVertexList());
    }

    /**
     * Compares two workflows by looking at their priorities
     *
     * @param other the Workflow to be compared to this
     * @return a negative int to be used by the Comparable interface
     */

    public int compareTo(Workflow other) {
        if (this.priority > other.priority) return 1;
        else if (other.priority > this.priority) return -1;
        return 0;
    }

    /**
     * Creates a list of workflows using the list of IOT Devices, LSDNs, and CSDNs
     *
     * @param IoTs   An ArrayList of IOT Devices to be used when generating workflows
     * @param LSDNs  The LSDNs to be used when generating workflows
     * @param CSDNs  The CSDNs to be used when generating workflows
     * @param number The number of workflows to be genrated
     * @return An ArrayList of workflows
     */

    public static ArrayList<Workflow> generateWorkflows(int number) {
        ArrayList<Workflow> workflows = new ArrayList<Workflow>();
        for (int i = 0; i < number; i++) {
            Workflow w = generateWorkflow();
            workflows.add(w);
        }
        return workflows;
    }

    public boolean stillValid() {
        ArrayList<Device> devicesTemp = new ArrayList<Device>(devices);
        for (int i = 0; i < devicesTemp.size() - 1; i++) {
            int k = i + 1;
            boolean isClosestLSDN = (devicesTemp.get(i) instanceof IoTDevice) ? devicesTemp.get(i).closestLSDN() == devicesTemp.get(k) : true;
            boolean isOwnDevice = (devicesTemp.get(i) instanceof LocalSDN && devicesTemp.get(k) instanceof IoTDevice) ? devicesTemp.get(k).closestLSDN() == devicesTemp.get(i) : true;
            boolean isAdjacentLSDN = (devicesTemp.get(i) instanceof LocalSDN && devicesTemp.get(k) instanceof LocalSDN) ? ((LocalSDN) devicesTemp.get(i)).isAdjacent((LocalSDN) devicesTemp.get(k)) : true;
            boolean iotsInSameCell = (devicesTemp.get(i) instanceof IoTDevice && devicesTemp.get(k) instanceof IoTDevice) ? ((IoTDevice) devicesTemp.get(i)).closestLSDN == ((IoTDevice) devicesTemp.get(k)).closestLSDN : true;
            if (!(devicesTemp.get(i).canTransmitTo(devicesTemp.get(k)) && isClosestLSDN && isOwnDevice && isAdjacentLSDN && iotsInSameCell))
                return false;
        }
        return true;
    }

    public void regenPath() {
        devices = getPath();
        if (devices == null) {
            regenPath();
            return;
        } else {
            ArrayList<Device> devicesTemp = new ArrayList<Device>(devices);
            for (int i = 0; i < devices.size() - 1; i++)
                connections.add(new Connection(devicesTemp.get(i), devicesTemp.get(i + 1)));
            for (Connection c : connections)
                c.workflow = this;
        }
    }

    /**
     * Generates an indivual workflow given IOT Devices, LSDNs, and CSDNs
     *
     * @param IoTs  An ArrayList of IOT Devices to be used when generating workflows
     * @param LSDNs The LSDNs to be used when generating workflows
     * @param CSDNs The CSDNs to be used when generating workflows
     * @return A single workflow generated using the passed lists of devices
     */


    public static Workflow generateWorkflow() {
        ArrayList<Device> allDevices = new ArrayList<Device>();
        allDevices.addAll(Simulation.iot_devices);
        allDevices.addAll(Simulation.LSDNs);

        Random r = new Random();
        int maxInd = allDevices.size();
        Workflow w = new Workflow(allDevices.get(r.nextInt(maxInd)), allDevices.get(r.nextInt(maxInd)));
        if (w.devices == null)
            return generateWorkflow();
        else
            return w;
    }

    /**
     * Adds a Device and a connection between it and the last element to the Workflow
     *
     * @param d The Device to be added to the workflow
     */

//    public void add(Device d) {
//        devices.add(d);
//        connections.add(new Connection(d, devices.peek()));
//    }

    /**
     * Adds a Connection and the Device it includes to the workflow
     *
     * @param c The connection to be added to the workflow
     * @throws IllegalArgumentException if the connection added does not add on to the workflow
     */

    public void add(Connection c) {
        if (connections.peek().endpoint() == c.startpoint()) {
            connections.add(c);
            devices.add(c.endpoint());
        } else {
            throw new IllegalArgumentException("Workflow devices must be connected");
        }
    }

    /**
     * Checks if all of the connections in the workflow are allocated
     *
     * @return whether or not all of connections are allocated
     */

    public boolean isExecutable() {
        for (Connection c : connections)
            if (c.getChannel() == null)
                return false;
        return true;
    }

    public String toString() {
        return "W" + id + "(R" + durationRemaining + " P" + priority + ")";
    }

    public String debugString() {
        return "{dataLeft: " + dataLeft + ", devices:" + devices + "}";
    }

}