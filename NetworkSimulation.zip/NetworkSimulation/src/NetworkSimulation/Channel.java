package NetworkSimulation;

import java.util.ArrayList;
import java.util.Random;
import java.awt.Color;

public class Channel {
	protected double bandwith;
	protected ArrayList<Connection> connections = new ArrayList<Connection>();;
	public int id;
	public static int next_id;
	public Color color;

	public Channel(double bandwith){
		this.bandwith = bandwith;
		id = next_id;
		next_id++;

		Random random = new Random();
		float h = random.nextFloat();
		float s = random.nextFloat();
		float b = random.nextFloat();
		color = Color.getHSBColor(h, s, b);
	}

	public Channel(){
		this(0);
		Random r = new Random();
		bandwith = r.nextGaussian() * Simulation.BANDWITH_SD + Simulation.BANDWITH_MEAN;
		while(bandwith <= 0){
			bandwith = r.nextGaussian() * Simulation.BANDWITH_SD + Simulation.BANDWITH_MEAN;
		}
	}

	public static ArrayList<Channel> generateChannels(){
		ArrayList<Channel> channels = new ArrayList<Channel>();
		for(int i = 0; i < Simulation.NUM_CHANNELS; i++){
			channels.add(new Channel());
		}
		return channels;
	}

	public void add(Connection c){
		connections.add(c);
	}

	public String toString(){
		String workflows = "[";
		for(Connection c: connections)	workflows +=  "("  + c.workflow + ")C"+ c.id + ", ";
		return "Channel" + id + " {connections: " + workflows + "]}";
	}
}