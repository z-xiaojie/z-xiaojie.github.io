package NetworkSimulation;

import java.util.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Color;

public class LocalSDN extends Device{
	private static final int HEIGHT = 6;
	private static final int WIDTH = 6;

	public ArrayList<Channel> channels = new ArrayList<Channel>();

	public ArrayList<Channel> channelsCanTransmit;
	public ArrayList<Channel> channelsCanReceive = new ArrayList<Channel>();

	public LocalSDN(double xcor, double ycor, double radius){
		super(xcor, ycor, radius);
		ArrayList<Channel> channelsTemp = new ArrayList<Channel>(Simulation.channels);
		Collections.shuffle(channelsTemp);
		channels = new ArrayList<Channel>(channelsTemp.subList(0, new Random().nextInt(Simulation.channels.size())));
		channelsCanTransmit = new ArrayList<Channel>(channels);
	}

	public static ArrayList<LocalSDN> genCornerLSDNs(double maxX, double maxY, double radius){
		return new ArrayList<LocalSDN>(Arrays.asList(new LocalSDN(maxX / 4.0, maxY / 4.0, radius), new LocalSDN(3 * maxX / 4.0, maxY / 4.0, radius), new LocalSDN(maxX / 4.0, 3 * maxY / 4.0, radius), new LocalSDN(3 * maxX / 4.0, 3 * maxY / 4.0, radius)));
	}

	public ArrayList<IoTDevice> getIoTs(ArrayList<IoTDevice> iots){
		ArrayList<IoTDevice> _iots = new ArrayList<IoTDevice>(iots);
		Iterator<IoTDevice> iter = _iots.iterator();
		while(iter.hasNext())
			if(iter.next().closestLSDN != this)	iter.remove();
		return _iots;
	}

	public boolean isAdjacent(LocalSDN other){
		ArrayList<LocalSDN> localSDNS = new ArrayList<>(Simulation.LSDNs);
		localSDNS.remove(this);
		return distance(other) - 10 < distance(closestLSDN(localSDNS));
	}

	public ArrayList<IoTDevice> getIoTs(){
		return getIoTs(Simulation.iot_devices);
	}

	public void paintComponent(Graphics g){
		setLocation((int) xcor * Simulation.SCALE - (WIDTH * Simulation.SCALE / 2), (int) ycor * Simulation.SCALE - (HEIGHT * Simulation.SCALE / 2));
		setSize(WIDTH * Simulation.SCALE , HEIGHT * Simulation.SCALE);
		setBackground(Color.RED);
		super.paintComponent(g);
	}

	public String toString(){
		return "LSDN" + id + "(" + xcor + ", " + ycor + ")";
	}
}