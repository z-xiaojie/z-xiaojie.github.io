package NetworkSimulation;

import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.util.Stack;


public class Device extends JPanel{
	protected double radius;
	protected int id;

	protected double xcor;
	protected double ycor;

	private final static int HEIGHT = 2;
	private final static int WIDTH = 2;

	private static int nextID = 0;

	public double xcor(){return xcor;}
	public double ycor(){return ycor;}
	public double radius(){return radius;}
	public int id(){return id;}

	public Device(double xcor, double ycor, double radius){
		this.xcor = xcor;
		this.ycor = ycor;
		this.radius = radius;
		id = nextID;
		nextID++;
	}

	public double distance(Device d){
		return Math.sqrt(Math.pow((d.xcor - xcor), 2) + Math.pow((d.ycor - ycor), 2));
	}

	// public void paintComponent(Graphics g){
	// 	setLocation((int) xcor * Simulation.SCALE - (WIDTH * Simulation.SCALE / 2), (int) ycor * Simulation.SCALE - (HEIGHT * Simulation.SCALE / 2));
	// 	setSize(WIDTH * Simulation.SCALE , HEIGHT * Simulation.SCALE);
	// 	setBackground(Color.BLACK);
	// 	super.paintComponent(g);
	// }

	public IoTDevice randIoTInRange(ArrayList<IoTDevice> devices){
		ArrayList<IoTDevice> devicesInRange = new ArrayList<IoTDevice>();
		for(IoTDevice d: devices){
			if(distance(d) < radius){
				devicesInRange.add(d);
			}
		}
		int randIndex = (int) (Math.random() * devicesInRange.size());
		return devicesInRange.get(randIndex);
	}

	public LocalSDN randLSDNInRange(ArrayList<LocalSDN> devices){
		ArrayList<LocalSDN> devicesInRange = new ArrayList<LocalSDN>();
		for(LocalSDN d: devices){
			if(distance(d) < radius){
				devicesInRange.add(d);
			}
		}
		int randIndex = (int) (Math.random() * devicesInRange.size());
		return devicesInRange.get(randIndex);
	}

	public CentralSDN randCSDNInRange(ArrayList<CentralSDN> devices){
		ArrayList<CentralSDN> devicesInRange = new ArrayList<CentralSDN>();
		for(CentralSDN d: devices){
			if(distance(d) < radius){
				devicesInRange.add(d);
			}
		}
		int randIndex = (int) (Math.random() * devicesInRange.size());
		return devicesInRange.get(randIndex);
	}

	public LocalSDN closestLSDN(ArrayList<LocalSDN> LSDNs){
		double minDist = distance(LSDNs.get(0));
		LocalSDN closest = LSDNs.get(0);
		for(LocalSDN lsdn: LSDNs){
			double dist = distance(lsdn);
			if(dist < minDist){
				closest = lsdn;
				minDist = dist;
			}
		}
		return closest;
	}

	public LocalSDN closestLSDN(){
		return closestLSDN(Simulation.LSDNs);
	}


	public CentralSDN findClosestCSDN(ArrayList<CentralSDN> CSDNs){
		double minDistance = Double.MAX_VALUE;
		CentralSDN closest = CSDNs.get(0);
		for(CentralSDN d: CSDNs){
			if(distance(d) < minDistance){
				minDistance = distance(d);
				closest = d;
			}
		}
		return closest;
	}

	public boolean canTransmitTo(Device other){
		if(other == this)	return false;
		return radius >= distance(other);
	}

	public boolean equals(Device other){
		return other.id == this.id; 
	}

	public String toString(){
		return "D(" + xcor + ", " + ycor + ")";
	}
}